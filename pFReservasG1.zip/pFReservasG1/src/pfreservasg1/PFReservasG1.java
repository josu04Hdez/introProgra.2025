/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package pfreservasg1;

import javax.swing.JOptionPane;

public class PFReservasG1 {

    public static void main(String[] args) {
       int ingresoSistema = Integer.parseInt(JOptionPane.showInputDialog("Bienvenido! ¿Desea ingresar al sistema? (SI = 1 / NO = 0):"));
        if (ingresoSistema == 1) {
            boolean continuar = true;
            Empleados empleados = new Empleados();
            while (continuar) {
                int opcion = Integer.parseInt(JOptionPane.showInputDialog(
                        "Plataforma de Reservación y Administración de Espacios:\n"
                        + "1. Registro de datos de los empleados.\n"
                        + "2. Detalles de las Reservas.\n"
                        + "3. Parqueos.\n"
                        + "4. Salas / Áreas comunes.\n"
                        + "5. Administrador.\n"
                        + "6. Salir.\n"
                        + "Seleccione una opción:"));

                switch (opcion) {
                    case 1:
                        empleados.definirCantidadEmpleados();
                        empleados.registroEmpleados();
                        empleados.mostrarEmpleados();
                        break;
                    case 2:
                        break;
                    case 3:
                        break;
                    case 4:
                        break;
                    case 5:
                        break;
                    case 6:
                        JOptionPane.showMessageDialog(null, "Saliendo del programa.");
                        continuar = false;
                        break;
                    default:
                        JOptionPane.showMessageDialog(null, "Opción inválida. Intente nuevamente.");
                }
            }
        } else {
            JOptionPane.showMessageDialog(null, "Saliendo del sistema.");
        }
    }
}

   
