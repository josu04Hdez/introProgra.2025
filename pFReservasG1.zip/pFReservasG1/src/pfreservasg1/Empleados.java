/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package pfreservasg1;

import javax.swing.JOptionPane;

class Empleados {
    private int[] id;
    private String[] nombre;
    private String[] departamento;
    private int contador;

    // Constructor vacío para inicializar después
    public Empleados() {
        id = new int[0];
        nombre = new String[0];
        departamento = new String[0];
        contador = 0;
    }

    // Método para definir la cantidad de empleados a registrar
    public void definirCantidadEmpleados() {
        int cantidadEmpleados = 0;
        while (cantidadEmpleados <= 0) {
            try {
                String input = JOptionPane.showInputDialog("¿Cuántos empleados desea registrar?");
                cantidadEmpleados = Integer.parseInt(input);
                if (cantidadEmpleados <= 0) { // si el usuario se equivoca o pone un 0 se seguira consultando hasta que cancele o de el numero
                    JOptionPane.showMessageDialog(null, "Ingrese un número mayor a 0.");
                }
            } catch (NumberFormatException e) { //URGENTE, preguntar si es valido usar el catch cuando ponen letras y lo identifique
                JOptionPane.showMessageDialog(null, "Ingrese un número válido.");
            }
        }
        id = new int[cantidadEmpleados];
        nombre = new String[cantidadEmpleados];
        departamento = new String[cantidadEmpleados];
        contador = 0;
    }

    // Método para registrar empleados
    public void registroEmpleados() {
        while (contador < id.length) {
            String idInput = JOptionPane.showInputDialog("Ingrese ID del empleado(a) " + (contador + 1) + ":");
            if (idInput.matches("[0-9]+")) { //Urgente consult del matches para solo numeros y que se identifique cuando ponen letras 
                id[contador] = Integer.parseInt(idInput);
                nombre[contador] = JOptionPane.showInputDialog("Ingrese el Nombre del empleado(a) " + (contador + 1) + ":");
                departamento[contador] = JOptionPane.showInputDialog("Ingrese Departamento en que trabaja el empleado(a) " + (contador + 1) + ":");
                contador++;
            } else {
                JOptionPane.showMessageDialog(null, "Error: El ID debe ser un número válido.");
            }
        }
    }

    // Método para mostrar la lista de empleados registrados
    public void mostrarEmpleados() {
        String resultado = "Lista de Empleados:\n";
        for (int i = 0; i < contador; i++) {
            resultado += "ID: " + id[i] + ", Nombre: " + nombre[i] + ", Departamento: " + departamento[i] + "\n";
        }
        JOptionPane.showMessageDialog(null, resultado);
    }
}